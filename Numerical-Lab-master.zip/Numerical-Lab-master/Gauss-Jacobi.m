function retval =GaussJacobi(A, B)
  A
  B'
endfunction
